const plantForumList = [
    {
      id: 1,
      name: 'Succulent',
      forum: {
        location: 'Arlington',
        chat: [
            { name: 'Misty', message: 'Great for beginners growing here in Arlington!' },
            { name: 'Bob', message: 'I’ve been growing every year and I love it!' },
          ],
      },
    },
    {
      id: 2,
      name: 'Lantana',
      forum: {
        location: 'Arlington',
        chat: [
            { name: 'Misty', message: 'Great for beginners growing here in Arlington!' },
            { name: 'Bob', message: 'I’ve been growing every year and I love it!' },
          ],
      },
    },
    {
      id: 3,
      name: 'Dawf Yaupon',
      forum: {
        location: 'Arlington',
        chat: [
            { name: 'Misty', message: 'Great for beginners growing here in Arlington!' },
            { name: 'Bob', message: 'I’ve been growing every year and I love it!' },
          ],
      },
    },
    {
      id: 4,
      name: 'E.Eyed Susan',
      forum: {
        location: 'Arlington',
        chat: [
            { name: 'Misty', message: 'Great for beginners growing here in Arlington!' },
            { name: 'Bob', message: 'I’ve been growing every year and I love it!' },
          ],
      },
    },
    {
      id: 5,
      name: 'Parsley',
      forum: {
        location: 'Arlington',
        chat: [
            { name: 'Misty', message: 'Great for beginners growing here in Arlington!' },
            { name: 'Bob', message: 'I’ve been growing every year and I love it!' },
          ],
      },
    },
    {
      id: 6,
      name: 'Cilantro',
      forum: {
        location: 'Arlington',
        chat: [
          { name: 'Misty', message: 'Great for beginners growing here in Arlington!' },
          { name: 'Bob', message: 'I’ve been growing every year and I love it!' },
        ],
      },
    },
  ];
  
  
  export default plantForumList;