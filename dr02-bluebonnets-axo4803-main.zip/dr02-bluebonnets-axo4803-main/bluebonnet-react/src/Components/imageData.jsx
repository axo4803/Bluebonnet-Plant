const dashboardImg1 = "https://komodoreptile.com/wp-content/uploads/2022/01/93303-Climbing-Green-Leaf-Plant-SM-Detail-alt-1.png";
const dashboardImg2 = "https://komodoreptile.com/wp-content/uploads/2022/01/93303-Climbing-Green-Leaf-Plant-SM-Detail-alt-1.png";
const SeasonInsightsImg1 = "https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Cartoon_cloud.svg/1024px-Cartoon_cloud.svg.png"
const SeasonInsightsImg2 = "https://creazilla-store.fra1.digitaloceanspaces.com/cliparts/1684366/cloud-with-rain-clipart-md.png"



export {dashboardImg1,dashboardImg2,SeasonInsightsImg1,SeasonInsightsImg2};